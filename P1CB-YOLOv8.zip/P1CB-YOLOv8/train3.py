from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('yolov8s+P1CB.yaml')
    model.train(
        data='TT100K.yaml',
        epochs=300,
        batch=12,
        device=0,
        amp=False,
        task='detect',
        mode='train'
    )