from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('yolov8s+P1CB.yaml')
    model.train(
        data='VisDrone.yaml',
        epochs=300,
        batch=2,
        device=0,
        amp=False,
        task='detect',
        mode='train'
    )