# Ultralytics YOLO 🚀, GPL-3.0 license
"""
Common modules
"""

import math

import torch
import torch.nn as nn

from ultralytics.yolo.utils.tal import dist2bbox, make_anchors
from ultralytics.nn.DAM import num_DAM

class DSPPF(nn.Module):
    # Dynamic Aggregation Mechanism (DAM)
    def __init__(self, c1, c2, k=5, n=num_DAM()):
        super().__init__()
        c_ = c2 // 2 # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)

        # Create a list to hold the dynamic number of pooling layers
        self.pool_layers = nn.ModuleList([nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2) for _ in range(n - 1)])
        self.cv2 = Conv(c_ * n, c2, 1, 1)

    def forward(self, x):
        x = self.cv1(x)
        y = [x]

        # Apply the dynamic number of pooling layers
        for pool_layer in self.pool_layers:
            y.append(pool_layer(y[-1]))

        return self.cv2(torch.cat(y, 1))


def autopad(k, p=None, d=1):  # kernel, padding, dilation
    # Pad to 'same' shape outputs
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]  # actual kernel-size
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
    return p


class Conv(nn.Module):
    # Standard convolution with args(ch_in, ch_out, kernel, stride, padding, groups, dilation, activation)
    default_act = nn.SiLU()  # default activation

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        return self.act(self.conv(x))


class DWConv(Conv):
    # Depth-wise convolution
    def __init__(self, c1, c2, k=1, s=1, d=1, act=True):  # ch_in, ch_out, kernel, stride, dilation, activation
        super().__init__(c1, c2, k, s, g=math.gcd(c1, c2), d=d, act=act)


class DWConvTranspose2d(nn.ConvTranspose2d):
    # Depth-wise transpose convolution
    def __init__(self, c1, c2, k=1, s=1, p1=0, p2=0):  # ch_in, ch_out, kernel, stride, padding, padding_out
        super().__init__(c1, c2, k, s, p1, p2, groups=math.gcd(c1, c2))


class ConvTranspose(nn.Module):
    # Convolution transpose 2d layer
    default_act = nn.SiLU()  # default activation

    def __init__(self, c1, c2, k=2, s=2, p=0, bn=True, act=True):
        super().__init__()
        self.conv_transpose = nn.ConvTranspose2d(c1, c2, k, s, p, bias=not bn)
        self.bn = nn.BatchNorm2d(c2) if bn else nn.Identity()
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv_transpose(x)))

    def forward_fuse(self, x):
        return self.act(self.conv_transpose(x))


class DFL(nn.Module):
    # Integral module of Distribution Focal Loss (DFL)
    # Proposed in Generalized Focal Loss https://ieeexplore.ieee.org/document/9792391
    def __init__(self, c1=16):
        super().__init__()
        self.conv = nn.Conv2d(c1, 1, 1, bias=False).requires_grad_(False)
        x = torch.arange(c1, dtype=torch.float)
        self.conv.weight.data[:] = nn.Parameter(x.view(1, c1, 1, 1))
        self.c1 = c1

    def forward(self, x):
        b, c, a = x.shape  # batch, channels, anchors
        return self.conv(x.view(b, 4, self.c1, a).transpose(2, 1).softmax(1)).view(b, 4, a)
        # return self.conv(x.view(b, self.c1, 4, a).softmax(1)).view(b, 4, a)


class TransformerLayer(nn.Module):
    # Transformer layer https://arxiv.org/abs/2010.11929 (LayerNorm layers removed for better performance)
    def __init__(self, c, num_heads):
        super().__init__()
        self.q = nn.Linear(c, c, bias=False)
        self.k = nn.Linear(c, c, bias=False)
        self.v = nn.Linear(c, c, bias=False)
        self.ma = nn.MultiheadAttention(embed_dim=c, num_heads=num_heads)
        self.fc1 = nn.Linear(c, c, bias=False)
        self.fc2 = nn.Linear(c, c, bias=False)

    def forward(self, x):
        x = self.ma(self.q(x), self.k(x), self.v(x))[0] + x
        x = self.fc2(self.fc1(x)) + x
        return x


class TransformerBlock(nn.Module):
    # Vision Transformer https://arxiv.org/abs/2010.11929
    def __init__(self, c1, c2, num_heads, num_layers):
        super().__init__()
        self.conv = None
        if c1 != c2:
            self.conv = Conv(c1, c2)
        self.linear = nn.Linear(c2, c2)  # learnable position embedding
        self.tr = nn.Sequential(*(TransformerLayer(c2, num_heads) for _ in range(num_layers)))
        self.c2 = c2

    def forward(self, x):
        if self.conv is not None:
            x = self.conv(x)
        b, _, w, h = x.shape
        p = x.flatten(2).permute(2, 0, 1)
        return self.tr(p + self.linear(p)).permute(1, 2, 0).reshape(b, self.c2, w, h)


class Bottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, k=(3, 3), e=0.5):  # ch_in, ch_out, shortcut, groups, kernels, expand
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, k[0], 1)
        self.cv2 = Conv(c_, c2, k[1], 1, g=g)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.cv2(self.cv1(x)) if self.add else self.cv2(self.cv1(x))


class BottleneckCSP(nn.Module):
    # CSP Bottleneck https://github.com/WongKinYiu/CrossStagePartialNetworks
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = nn.Conv2d(c1, c_, 1, 1, bias=False)
        self.cv3 = nn.Conv2d(c_, c_, 1, 1, bias=False)
        self.cv4 = Conv(2 * c_, c2, 1, 1)
        self.bn = nn.BatchNorm2d(2 * c_)  # applied to cat(cv2, cv3)
        self.act = nn.SiLU()
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

    def forward(self, x):
        y1 = self.cv3(self.m(self.cv1(x)))
        y2 = self.cv2(x)
        return self.cv4(self.act(self.bn(torch.cat((y1, y2), 1))))


class C3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, k=((1, 1), (3, 3)), e=1.0) for _ in range(n)))

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), 1))


class C2(nn.Module):
    # CSP Bottleneck with 2 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        self.c = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv(2 * self.c, c2, 1)  # optional act=FReLU(c2)
        # self.attention = ChannelAttention(2 * self.c)  # or SpatialAttention()
        self.m = nn.Sequential(*(Bottleneck(self.c, self.c, shortcut, g, k=((3, 3), (3, 3)), e=1.0) for _ in range(n)))

    def forward(self, x):
        a, b = self.cv1(x).chunk(2, 1)
        return self.cv2(torch.cat((self.m(a), b), 1))


class C2f(nn.Module):
    # CSP Bottleneck with 2 convolutions
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        self.c = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.ModuleList(Bottleneck(self.c, self.c, shortcut, g, k=((3, 3), (3, 3)), e=1.0) for _ in range(n))

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))

    def forward_split(self, x):
        y = list(self.cv1(x).split((self.c, self.c), 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))


class ChannelAttention(nn.Module):
    # Channel-attention module https://github.com/open-mmlab/mmdetection/tree/v3.0.0rc1/configs/rtmdet
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Conv2d(channels, channels, 1, 1, 0, bias=True)
        self.act = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x * self.act(self.fc(self.pool(x)))


class SpatialAttention(nn.Module):
    # Spatial-attention module
    def __init__(self, kernel_size=7):
        super().__init__()
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.cv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.act = nn.Sigmoid()

    def forward(self, x):
        return x * self.act(self.cv1(torch.cat([torch.mean(x, 1, keepdim=True), torch.max(x, 1, keepdim=True)[0]], 1)))


class CBAM(nn.Module):
    # Convolutional Block Attention Module
    def __init__(self, c1, kernel_size=7):  # ch_in, kernels
        super().__init__()
        self.channel_attention = ChannelAttention(c1)
        self.spatial_attention = SpatialAttention(kernel_size)

    def forward(self, x):
        return self.spatial_attention(self.channel_attention(x))

class CoordAttEnhanced(nn.Module):
    """ Enhanced Coordinate Attention for Small Objects, also called CoordAttv2 """
    def __init__(self, c1, c2=None, reduction=8, kernel_size=3):
        super().__init__()
        c2 = c2 or c1
        self.c1 = c1
        self.c2 = c2
        mip = max(8, c1 // reduction)

        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        self.conv1 = nn.Conv2d(c1, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = nn.SiLU()

        self.conv_h = nn.Conv2d(mip, c2, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, c2, kernel_size=1, stride=1, padding=0)

        # 空间平滑卷积（深度可分离，不增加参数量）
        self.smooth = nn.Conv2d(c2, c2, kernel_size=kernel_size, padding=kernel_size//2, groups=c2, bias=False)
        self.bn_smooth = nn.BatchNorm2d(c2)

        # 可学习残差权重
        self.res_weight = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        identity = x
        n, c, h, w = x.size()

        # 原始坐标池化
        x_h = self.pool_h(x)
        x_w = self.pool_w(x)

        # 拼接并降维
        y = torch.cat([x_h, x_w.permute(0, 1, 3, 2)], dim=2)  # [N, C, H+W, 1]
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        # 分割回高度和宽度
        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)

        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()

        # 注意力图 = a_h * a_w
        att = a_w * a_h  # [N, C2, H, W]

        # 空间平滑
        att_smooth = self.bn_smooth(self.smooth(att))

        # 融合：原始特征 + 可学习权重的注意力特征
        out = identity * (att_smooth + self.res_weight * identity)
        return out

class BiFPN_Fusion_Improved(nn.Module):
    """改进版BiFPN融合模块
    - 使用快速归一化融合 (ReLU + eps)
    - 残差连接
    - 深度可分离卷积 + SE注意力
    """
    def __init__(self, c1, c2, num_inputs=2, use_dw=True, eps=1e-4):
        super().__init__()
        self.num_inputs = num_inputs
        self.eps = eps
        
        # 输入投影层：将不同通道数的输入投影到统一的 c2
        if isinstance(c1, (list, tuple)):
            self.input_proj = nn.ModuleList([
                Conv(ch, c2, 1, 1) if ch != c2 else nn.Identity()
                for ch in c1
            ])
        else:
            self.input_proj = nn.ModuleList([
                Conv(c1, c2, 1, 1) if c1 != c2 else nn.Identity()
                for _ in range(num_inputs)
            ])
        
        # 可学习权重 (初始化为1.0，经ReLU后为正)
        self.w = nn.Parameter(torch.ones(num_inputs, dtype=torch.float32), requires_grad=True)
        
        # 融合后的特征处理
        if use_dw:
            self.fusion_conv = nn.Sequential(
                DWConv(c2, c2, 3),
                Conv(c2, c2, 1, 1),
                SEAttention(c2, reduction=16)       # 通道注意力增强
            )
        else:
            self.fusion_conv = nn.Sequential(
                Conv(c2, c2, 3, 1),
                SEAttention(c2, reduction=16)
            )
        
        # 残差连接条件
        self.residual = (isinstance(c1, int) and c1 == c2) or \
                        (isinstance(c1, (list, tuple)) and all(ch == c2 for ch in c1))

    def forward(self, x):
        if not isinstance(x, list):
            x = [x]
        
        # 1. 通道对齐
        proj_features = []
        for i, feat in enumerate(x):
            proj_features.append(self.input_proj[i](feat))
        
        # 2. 空间尺寸对齐（统一到第一个输入的尺寸）
        target_size = proj_features[0].shape[-2:]
        for i in range(1, len(proj_features)):
            if proj_features[i].shape[-2:] != target_size:
                proj_features[i] = nn.functional.interpolate(
                    proj_features[i], size=target_size, mode='nearest'
                )
        
        # 3. 快速归一化融合权重
        w = torch.relu(self.w[:len(proj_features)])
        w_sum = w.sum() + self.eps
        w_norm = w / w_sum
        
        # 4. 加权求和
        fused = torch.zeros_like(proj_features[0])
        for i, feat in enumerate(proj_features):
            fused = fused + w_norm[i] * feat
        
        # 5. 融合卷积 + 残差
        out = self.fusion_conv(fused)
        if self.residual:
            # 当所有输入通道与 c2 相同时，添加残差连接
            identity = proj_features[0] if len(proj_features) == 1 else fused
            out = out + identity
        
        return out

class SEAttention(nn.Module):
    """Squeeze-and-Excitation Channel Attention"""
    def __init__(self, channels, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels, bias=False),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)
class BiFPN_Fusion_Stable(nn.Module):
    """Stable BiFPN,
    - 保留原始 softmax 权重归一化，训练稳定
    - 增强卷积部分：深度可分离卷积 + 两层标准卷积，提升融合后特征表达
    - 无残差连接，避免特征冗余
    """
    def __init__(self, c1, c2, num_inputs=2, use_dw=True):
        super().__init__()
        self.num_inputs = num_inputs
        
        # 输入投影层：将不同通道数的输入投影到统一的 c2
        if isinstance(c1, (list, tuple)):
            self.input_proj = nn.ModuleList([
                Conv(ch, c2, 1, 1) if ch != c2 else nn.Identity()
                for ch in c1
            ])
        else:
            self.input_proj = nn.ModuleList([
                Conv(c1, c2, 1, 1) if c1 != c2 else nn.Identity()
                for _ in range(num_inputs)
            ])
        
        # 可学习权重（初始化为0，通过softmax得到均匀初始权重）
        self.w = nn.Parameter(torch.zeros(num_inputs, dtype=torch.float32))
        
        # 融合后的特征处理：增强版卷积链
        if use_dw:
            self.fusion_conv = nn.Sequential(
                DWConv(c2, c2, 3),          # 深度可分离卷积（轻量）
                Conv(c2, c2, 1, 1),          # 1x1 通道融合
                Conv(c2, c2, 3, 1)           # 3x3 进一步提取空间特征
            )
        else:
            self.fusion_conv = nn.Sequential(
                Conv(c2, c2, 3, 1),
                Conv(c2, c2, 3, 1)
            )
    
    def forward(self, x):
        if not isinstance(x, list):
            x = [x]
        
        # 1. 通道对齐
        proj_features = []
        for i, feat in enumerate(x):
            proj_features.append(self.input_proj[i](feat))
        
        # 2. 空间尺寸对齐（统一到第一个输入的尺寸）
        target_size = proj_features[0].shape[-2:]
        for i in range(1, len(proj_features)):
            if proj_features[i].shape[-2:] != target_size:
                proj_features[i] = nn.functional.interpolate(
                    proj_features[i], size=target_size, mode='nearest'
                )
        
        # 3. Softmax 权重归一化（稳定训练）
        w = torch.softmax(self.w[:len(proj_features)], dim=0)
        
        # 4. 加权求和
        fused = sum(w[i] * proj_features[i] for i in range(len(proj_features)))
        
        # 5. 融合卷积增强
        return self.fusion_conv(fused)
class BiFPN_Concat(nn.Module):
    def __init__(self, c1, c2, n=1):
        super().__init__()
        self.c = c1 // 2
        self.cv1 = Conv(c1, self.c, 1, 1)
        self.cv2 = Conv(c1, self.c, 1, 1)
        self.cv3 = Conv(c2, c2, 3, 1)
    def forward(self, x):
        # 加权特征融合
        return self.cv3(torch.cat((self.cv1(x[0]), self.cv2(x[1])), dim=1))


class WeightedConcat(nn.Module):
    """BiFPN风格的加权特征融合 - 学习最优的融合权重
    支持不同通道数的输入，自动通过1x1卷积投影到相同通道数
    使用数值稳定的softmax权重归一化
    """
    def __init__(self, c1, c2=None, num_inputs=2, eps=1e-4):
        super().__init__()
        self.d = 1  # 默认在通道维度(dim=1)操作
        self.num_inputs = num_inputs
        self.eps = eps
        
        # 确定输出通道数
        if c2 is None:
            c2 = c1 if isinstance(c1, int) else max(c1)
        self.c2 = c2
        
        # 输入投影：将不同通道数的输入投影到相同的c2通道
        if isinstance(c1, list):
            # 每个输入可能有不同的通道数
            self.input_proj = nn.ModuleList([
                Conv(c1[i], c2, 1, 1) if c1[i] != c2 else nn.Identity()
                for i in range(num_inputs)
            ])
        else:
            # 所有输入通道数相同，只需要一个投影
            self.input_proj = nn.ModuleList([
                Conv(c1, c2, 1, 1) if c1 != c2 else nn.Identity()
                for _ in range(num_inputs)
            ])
        
        # 可学习的权重参数 - 使用较小的初始值，避免初始权重差异过大
        self.w = nn.Parameter(torch.zeros(num_inputs, dtype=torch.float32))
        
    def forward(self, x):
        # 确保输入是列表
        if not isinstance(x, list):
            x = [x]
        
        # 投影到相同通道数
        x_proj = [self.input_proj[i](x[i]) for i in range(len(x))]
        
        # 使用softmax进行数值稳定的权重归一化
        # 初始时所有权重接近相等(1/num_inputs)，训练后逐渐分化
        w = torch.softmax(self.w[:len(x)], dim=0)
        
        # 加权融合 - 使用stack和einsum更稳定
        x_stack = torch.stack(x_proj, dim=0)  # [num_inputs, B, C, H, W]
        w_view = w.view(-1, 1, 1, 1, 1)  # [num_inputs, 1, 1, 1, 1]
        out = (w_view * x_stack).sum(dim=0)  # [B, C, H, W]
        
        return out

class CrossScaleFusion(nn.Module):
    """跨尺度特征融合 - 增强小目标特征传播
    修复：使用InstanceNorm替代BatchNorm，支持batch=1
    """
    def __init__(self, c1, c2, num_scales=3):
        super().__init__()
        self.num_scales = num_scales
        
        # 多尺度池化
        self.pools = nn.ModuleList([
            nn.AdaptiveAvgPool2d((2**i, 2**i)) for i in range(num_scales)
        ])
        
        # 特征提取 - 使用InstanceNorm支持batch=1
        self.conv = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(c1, c1 // num_scales, 1, 1, 0, bias=False),
                nn.InstanceNorm2d(c1 // num_scales),
                nn.SiLU()
            ) for _ in range(num_scales)
        ])
        
        # 融合 - 使用InstanceNorm
        self.fusion = nn.Sequential(
            nn.Conv2d(c1, c2, 1, 1, 0, bias=False),
            nn.InstanceNorm2d(c2),
            nn.SiLU()
        )
        
        # 通道注意力（无BN）
        self.attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c2, c2 // 16, 1),
            nn.SiLU(),
            nn.Conv2d(c2 // 16, c2, 1),
            nn.Sigmoid()
        )
        
    def forward(self, x):
        b, c, h, w = x.shape
        
        multi_scale_features = []
        for i, (pool, conv) in enumerate(zip(self.pools, self.conv)):
            feat = pool(x)
            feat = conv(feat)
            # 上采样回原尺寸
            feat = nn.functional.interpolate(feat, size=(h, w), mode='nearest')
            multi_scale_features.append(feat)
        
        # 拼接多尺度特征
        out = torch.cat(multi_scale_features, dim=1)
        out = self.fusion(out)
        
        # 通道注意力
        attn = self.attn(out)
        return out * attn


class C1(nn.Module):
    # CSP Bottleneck with 1 convolution
    def __init__(self, c1, c2, n=1):  # ch_in, ch_out, number
        super().__init__()
        self.cv1 = Conv(c1, c2, 1, 1)
        self.m = nn.Sequential(*(Conv(c2, c2, 3) for _ in range(n)))

    def forward(self, x):
        y = self.cv1(x)
        return self.m(y) + y


class C3x(C3):
    # C3 module with cross-convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        self.c_ = int(c2 * e)
        self.m = nn.Sequential(*(Bottleneck(self.c_, self.c_, shortcut, g, k=((1, 3), (3, 1)), e=1) for _ in range(n)))


class C3TR(C3):
    # C3 module with TransformerBlock()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = TransformerBlock(c_, c_, 4, n)


class C3Ghost(C3):
    # C3 module with GhostBottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(GhostBottleneck(c_, c_) for _ in range(n)))


class SPP(nn.Module):
    # Spatial Pyramid Pooling (SPP) layer https://arxiv.org/abs/1406.4729
    def __init__(self, c1, c2, k=(5, 9, 13)):
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * (len(k) + 1), c2, 1, 1)
        self.m = nn.ModuleList([nn.MaxPool2d(kernel_size=x, stride=1, padding=x // 2) for x in k])

    def forward(self, x):
        x = self.cv1(x)
        return self.cv2(torch.cat([x] + [m(x) for m in self.m], 1))


class SPPF(nn.Module):
    # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)

    def forward(self, x):
        x = self.cv1(x)
        y1 = self.m(x)
        y2 = self.m(y1)
        return self.cv2(torch.cat((x, y1, y2, self.m(y2)), 1))


class Focus(nn.Module):
    # Focus wh information into c-space
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv = Conv(c1 * 4, c2, k, s, p, g, act=act)
        # self.contract = Contract(gain=2)

    def forward(self, x):  # x(b,c,w,h) -> y(b,4c,w/2,h/2)
        return self.conv(torch.cat((x[..., ::2, ::2], x[..., 1::2, ::2], x[..., ::2, 1::2], x[..., 1::2, 1::2]), 1))
        # return self.conv(self.contract(x))


class GhostConv(nn.Module):
    # Ghost Convolution https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):  # ch_in, ch_out, kernel, stride, groups
        super().__init__()
        c_ = c2 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, k, s, None, g, act=act)
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, act=act)

    def forward(self, x):
        y = self.cv1(x)
        return torch.cat((y, self.cv2(y)), 1)


class GhostBottleneck(nn.Module):
    # Ghost Bottleneck https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=3, s=1):  # ch_in, ch_out, kernel, stride
        super().__init__()
        c_ = c2 // 2
        self.conv = nn.Sequential(
            GhostConv(c1, c_, 1, 1),  # pw
            DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
            GhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False), Conv(c1, c2, 1, 1,
                                                                            act=False)) if s == 2 else nn.Identity()

    def forward(self, x):
        return self.conv(x) + self.shortcut(x)


class Concat(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, dimension=1):
        super().__init__()
        self.d = dimension

    def forward(self, x):
        return torch.cat(x, self.d)


class Proto(nn.Module):
    # YOLOv8 mask Proto module for segmentation models
    def __init__(self, c1, c_=256, c2=32):  # ch_in, number of protos, number of masks
        super().__init__()
        self.cv1 = Conv(c1, c_, k=3)
        self.upsample = nn.ConvTranspose2d(c_, c_, 2, 2, 0, bias=True)  # nn.Upsample(scale_factor=2, mode='nearest')
        self.cv2 = Conv(c_, c_, k=3)
        self.cv3 = Conv(c_, c2)

    def forward(self, x):
        return self.cv3(self.cv2(self.upsample(self.cv1(x))))


class Ensemble(nn.ModuleList):
    # Ensemble of models
    def __init__(self):
        super().__init__()

    def forward(self, x, augment=False, profile=False, visualize=False):
        y = [module(x, augment, profile, visualize)[0] for module in self]
        # y = torch.stack(y).max(0)[0]  # max ensemble
        # y = torch.stack(y).mean(0)  # mean ensemble
        y = torch.cat(y, 1)  # nms ensemble
        return y, None  # inference, train output


# Model heads below ----------------------------------------------------------------------------------------------------


class Detect(nn.Module):
    # YOLOv8 Detect head for detection models
    dynamic = False  # force grid reconstruction
    export = False  # export mode
    shape = None
    anchors = torch.empty(0)  # init
    strides = torch.empty(0)  # init

    def __init__(self, nc=80, ch=()):  # detection layer
        super().__init__()
        self.nc = nc  # number of classes
        self.nl = len(ch)  # number of detection layers
        self.reg_max = 16  # DFL channels (ch[0] // 16 to scale 4/8/12/16/20 for n/s/m/l/x)
        self.no = nc + self.reg_max * 4  # number of outputs per anchor
        self.stride = torch.zeros(self.nl)  # strides computed during build
        c2, c3 = max((16, ch[0] // 4, self.reg_max * 4)), max(ch[0], self.nc)  # channels
        self.cv2 = nn.ModuleList(
            nn.Sequential(Conv(x, c2, 3), Conv(c2, c2, 3), nn.Conv2d(c2, 4 * self.reg_max, 1)) for x in ch)
        self.cv3 = nn.ModuleList(nn.Sequential(Conv(x, c3, 3), Conv(c3, c3, 3), nn.Conv2d(c3, self.nc, 1)) for x in ch)
        self.dfl = DFL(self.reg_max) if self.reg_max > 1 else nn.Identity()

    def forward(self, x):
        shape = x[0].shape  # BCHW
        for i in range(self.nl):
            x[i] = torch.cat((self.cv2[i](x[i]), self.cv3[i](x[i])), 1)
        if self.training:
            return x
        elif self.dynamic or self.shape != shape:
            self.anchors, self.strides = (x.transpose(0, 1) for x in make_anchors(x, self.stride, 0.5))
            self.shape = shape

        x_cat = torch.cat([xi.view(shape[0], self.no, -1) for xi in x], 2)
        if self.export and self.format in ('saved_model', 'pb', 'tflite', 'edgetpu', 'tfjs'):  # avoid TF FlexSplitV ops
            box = x_cat[:, :self.reg_max * 4]
            cls = x_cat[:, self.reg_max * 4:]
        else:
            box, cls = x_cat.split((self.reg_max * 4, self.nc), 1)
        dbox = dist2bbox(self.dfl(box), self.anchors.unsqueeze(0), xywh=True, dim=1) * self.strides
        y = torch.cat((dbox, cls.sigmoid()), 1)
        return y if self.export else (y, x)

    def bias_init(self):
        # Initialize Detect() biases, WARNING: requires stride availability
        m = self  # self.model[-1]  # Detect() module
        # cf = torch.bincount(torch.tensor(np.concatenate(dataset.labels, 0)[:, 0]).long(), minlength=nc) + 1
        # ncf = math.log(0.6 / (m.nc - 0.999999)) if cf is None else torch.log(cf / cf.sum())  # nominal class frequency
        for a, b, s in zip(m.cv2, m.cv3, m.stride):  # from
            a[-1].bias.data[:] = 1.0  # box
            b[-1].bias.data[:m.nc] = math.log(5 / m.nc / (640 / s) ** 2)  # cls (.01 objects, 80 classes, 640 img)


class Segment(Detect):
    # YOLOv8 Segment head for segmentation models
    def __init__(self, nc=80, nm=32, npr=256, ch=()):
        super().__init__(nc, ch)
        self.nm = nm  # number of masks
        self.npr = npr  # number of protos
        self.proto = Proto(ch[0], self.npr, self.nm)  # protos
        self.detect = Detect.forward

        c4 = max(ch[0] // 4, self.nm)
        self.cv4 = nn.ModuleList(nn.Sequential(Conv(x, c4, 3), Conv(c4, c4, 3), nn.Conv2d(c4, self.nm, 1)) for x in ch)

    def forward(self, x):
        p = self.proto(x[0])  # mask protos
        bs = p.shape[0]  # batch size

        mc = torch.cat([self.cv4[i](x[i]).view(bs, self.nm, -1) for i in range(self.nl)], 2)  # mask coefficients
        x = self.detect(self, x)
        if self.training:
            return x, mc, p
        return (torch.cat([x, mc], 1), p) if self.export else (torch.cat([x[0], mc], 1), (x[1], mc, p))


class Pose(Detect):
    # YOLOv8 Pose head for keypoints models
    def __init__(self, nc=80, kpt_shape=(17, 3), ch=()):
        super().__init__(nc, ch)
        self.kpt_shape = kpt_shape  # number of keypoints, number of dims (2 for x,y or 3 for x,y,visible)
        self.nk = kpt_shape[0] * kpt_shape[1]  # number of keypoints total
        self.detect = Detect.forward

        c4 = max(ch[0] // 4, self.nk)
        self.cv4 = nn.ModuleList(nn.Sequential(Conv(x, c4, 3), Conv(c4, c4, 3), nn.Conv2d(c4, self.nk, 1)) for x in ch)

    def forward(self, x):
        bs = x[0].shape[0]  # batch size
        kpt = torch.cat([self.cv4[i](x[i]).view(bs, self.nk, -1) for i in range(self.nl)], -1)  # (bs, 17*3, h*w)
        x = self.detect(self, x)
        if self.training:
            return x, kpt
        pred_kpt = self.kpts_decode(kpt)
        return torch.cat([x, pred_kpt], 1) if self.export else (torch.cat([x[0], pred_kpt], 1), (x[1], kpt))

    def kpts_decode(self, kpts):
        ndim = self.kpt_shape[1]
        y = kpts.clone()
        if ndim == 3:
            y[:, 2::3].sigmoid_()  # inplace sigmoid
        y[:, 0::ndim] = (y[:, 0::ndim] * 2.0 + (self.anchors[0] - 0.5)) * self.strides
        y[:, 1::ndim] = (y[:, 1::ndim] * 2.0 + (self.anchors[1] - 0.5)) * self.strides
        return y


class Classify(nn.Module):
    # YOLOv8 classification head, i.e. x(b,c1,20,20) to x(b,c2)
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        c_ = 1280  # efficientnet_b0 size
        self.conv = Conv(c1, c_, k, s, autopad(k, p), g)
        self.pool = nn.AdaptiveAvgPool2d(1)  # to x(b,c_,1,1)
        self.drop = nn.Dropout(p=0.0, inplace=True)
        self.linear = nn.Linear(c_, c2)  # to x(b,c2)

    def forward(self, x):
        if isinstance(x, list):
            x = torch.cat(x, 1)
        x = self.linear(self.drop(self.pool(self.conv(x)).flatten(1)))
        return x if self.training else x.softmax(1)
