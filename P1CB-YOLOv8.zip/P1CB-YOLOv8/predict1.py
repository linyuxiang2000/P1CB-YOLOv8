from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('VisDrone_YOLOv8s+P1CB.pt')
    model.predict(
        data='ultralytics/datasets/VisDrone.yaml',
        device=0,
        source='ultralytics/assets/small_object/0000353_06000_d_0000200.jpg',
        task='detect',
        mode='predict',
        save=True,
        project='.',
        name='output',
        exist_ok=True
    )